How to run the Health Monitoring Management System Using PHP and MySQL

1.Download the zip file

2.Extract the file and copy hmms folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

4.Open PHPMyAdmin (http://localhost/phpmyadmin)

5.Create a database with name hmmsdb

6.Import hmmsdb.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/hmms


Admin Credential
Username: admin
Password: Test@123

User Credential
Username: test1@gmail.com
Password: Test@123
Or You can register yourself as user.